r = np.linspace(4,22,num=20)
Vr0 = 0.12;
Vϕ0 = 0.918;  
Bϕ0 = 1e3;
